import numpy as np
from sklearn.metrics import mean_squared_error, r2_score
import torch

# For MLP/CNN (PyTorch)
def evaluate_torch_model(model, X_test, y_test, predict_func, device='cuda'):
    y_pred = predict_func(model, X_test, device=device)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    print(f"Test MSE: {mse:.4f}")
    print(f"Test R2: {r2:.4f}")
    return mse, r2

# For RandomForest, LinearRegression (sklearn)
def evaluate_sklearn_model(model, X_test, y_test):
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    print(f"Test MSE: {mse:.4f}")
    print(f"Test R2: {r2:.4f}")
    return mse, r2

# Plotting
import matplotlib.pyplot as plt

def plot_predictions(y_true, y_pred, save_path='plots/pred_vs_true.pdf'):
    plt.figure(figsize=(6,6))
    plt.scatter(y_true, y_pred, alpha=0.5)
    plt.xlabel('True Score')
    plt.ylabel('Predicted Score')
    plt.title('Predicted vs True Scores')
    plt.plot([min(y_true), max(y_true)], [min(y_true), max(y_true)], 'r--')
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()
    print(f"Plot saved to {save_path}")
