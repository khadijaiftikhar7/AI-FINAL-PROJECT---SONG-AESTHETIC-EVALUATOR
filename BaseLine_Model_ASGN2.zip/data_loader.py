
from huggingface_hub import login
from datasets import load_dataset, Audio
import pandas as pd

def load_data():
  login(token="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")

  # Downloading the dataset

  dataset = load_dataset("ASLP-lab/SongEval", split="train")
  dataset = dataset.cast_column("audio", Audio(decode=False))

  return dataset

def flatten_dataset(dataset):

  rows = []
  for song in dataset:
      song_path = song['audio']['path']
      for ann in song['annotation']:
          ann['song_path'] = song_path
          rows.append(ann)

  flat_df = pd.DataFrame(rows)
  return flat_df
