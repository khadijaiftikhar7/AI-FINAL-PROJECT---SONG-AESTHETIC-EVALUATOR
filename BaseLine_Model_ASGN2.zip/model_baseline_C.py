import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
import numpy as np

# Simple CNN (Convolutional Neural Network)
# Basically what it does is take the input
# and pass it through diff layers
# there much shii happens and the model
# learns different features of the data

class MelSpecCNN(nn.Module):
    def __init__(self, n_mels=128, time_dim=313):
      super().__init__()
      self.conv = nn.Sequential(
              nn.Conv2d(1, 16, 3, padding=1),
              nn.ReLU(),
              nn.MaxPool2d(2),
              nn.Conv2d(16, 32, 3, padding=1),
              nn.ReLU(),
              nn.MaxPool2d(2)
          )
      self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(32 * (n_mels // 4) * (time_dim // 4), 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )

    def forward(self, x):
      x = self.conv(x)
      x = self.fc(x)
      return x.squeeze(-1)

def train_baseline_C(mel_specs, targets, epochs=10, batch_size=16, lr=1e-3, device='cuda'):

    # mel_specs: (num_samples, n_mels, time_dim)
    # targets: (num_samples,)


    # Adjusting the spectograms according to our CNN
    mel_specs = torch.tensor(mel_specs).unsqueeze(1).float()
    targets_float = targets.astype(np.float32)
    targets = torch.tensor(targets_float)

    # Making a Dataset of Tensors (arrays in PyTorch)
    dataset = TensorDataset(mel_specs, targets)

    # Making an DataLoader object from the dataset
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    # Loading our CNN and moving it to device (GPU if possible)
    model = MelSpecCNN(n_mels=mel_specs.shape[2], time_dim=mel_specs.shape[3]).to(device)

    # Loading Optimizer
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    # Selecting Loss function
    loss_fn = nn.MSELoss()

    # Training Loops
    model.train()
    for epoch in range(epochs):
        total_loss = 0
        for X_batch, y_batch in loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            optimizer.zero_grad()
            preds = model(X_batch)
            loss = loss_fn(preds, y_batch)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * X_batch.size(0)
        print(f"Epoch {epoch+1}/{epochs}, Loss: {total_loss/len(dataset):.4f}")

    return model

def predict_baseline_C(model, mel_specs, device='cuda'):
    model.eval()
    mel_specs = torch.tensor(mel_specs).unsqueeze(1).float().to(device)
    with torch.no_grad():
        preds = model(mel_specs).cpu().numpy()
    return preds

