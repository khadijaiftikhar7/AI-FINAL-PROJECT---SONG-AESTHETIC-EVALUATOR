from model_baseline_A import train_baseline_A, predict_baseline_A
from model_baseline_B import train_baseline_B, predict_baseline_B
from model_baseline_C import train_baseline_C, predict_baseline_C
from model_baseline_D import train_baseline_D, predict_baseline_D
import joblib
import torch

def train_model(X_train, y_train, save_path, model_name, device='cuda'):
  if model_name == 'A':
    model = train_baseline_A(X_train, y_train)
    joblib.dump(model, save_path)
    print(f"Model saved to {save_path}")
    return model

  elif model_name == 'B':
    model = train_baseline_B(X_train, y_train)
    joblib.dump(model, save_path)
    print(f"Model saved to {save_path}")
    return model

  elif model_name == 'C':
    model = train_baseline_C(
        mel_specs=X_train,
        targets=y_train,
        epochs=10,
        batch_size=16,
        lr=1e-3,
        device=device
        )
    torch.save(model.state_dict(), save_path)
    print(f"Model saved to {save_path}")
    return model

  elif model_name == 'D':
    model = train_baseline_D(
        X_train,
        y_train,
        epochs=10,
        batch_size=16,
        lr=1e-3,
        device=device
        )
    torch.save(model.state_dict(), save_path)
    print(f"Model saved to {save_path}")
    return model
  else:
    raise ValueError("model_name must be 'A', 'B', 'C' or 'D'")
