from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression

# Trains model based on data provided
# Model can be either Random Forest (rf) or Linear Regression (lr)
# Args:
# X_train (inputs of training data)
# y_train (outputs of training data)
# model (either rf or lr)

def train_baseline_A(X_train, y_train, model='lr'):
  if model == 'rf':
    model = RandomForestRegressor(n_estimators=100, random_state=67)
  elif model == 'lr':
    model = LinearRegression()
  else:
    raise ValueError("model must be 'rf' or 'lr'")

  model.fit(X_train, y_train)
  return model

# Uses model trained and makes predictions of test dataset inputs
def predict_baseline_A(model, X_test):
  return model.predict(X_test)
