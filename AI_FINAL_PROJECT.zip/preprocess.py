import torch
import torchaudio
import numpy as np
import os
import gc
from tqdm import tqdm
from data_loader import flatten_dataset
import pandas as pd
from mutagen.mp3 import MP3
import torch.nn.functional as F


import gc
import torch

def clear_memory():
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

# Use in your processing loop or modify your save_mel_spectrograms_batched function
# to call clear_memory() after each batch

def load_audio(file_path, target_sr=16000, device='cpu'):
  waveform, sr = torchaudio.load(file_path) # returns the audio in form of waveform which is processed as integers by the computer
  waveform = waveform.float()

  # sr is the quality of song we require (like how many frames of the sound)
  # We need to transform our song to the required one if its not in the right format
  if sr != target_sr:
    waveform = torchaudio.transforms.Resample(orig_freq=sr, new_freq=target_sr)(waveform)

    waveform = waveform.mean(dim=0).unsqueeze(0)

    # Moving to device
    return waveform.to(device)


# Calculating diff features like centroid, bandwidth, flatness and richness
def compute_features(y, sr=16000, device='cpu'):
    y = y.squeeze(0)

    S = torch.stft(y, n_fft=1024, hop_length=512, return_complex=True)
    S = torch.abs(S)

    freqs = torch.linspace(0, sr/2, S.shape[0], device=device)
    power = S**2

    centroid = (freqs[:, None] * power).sum() / (power.sum() + 1e-10)
    bandwidth = torch.sqrt(((freqs[:, None] - centroid)**2 * power).sum() / (power.sum() + 1e-10))
    flatness = torch.exp(torch.mean(torch.log(S + 1e-10))) / (S.mean() + 1e-10)
    richness = (S > 0.01 * S.max()).float().mean()

    return {
        'centroid': centroid.item(),
        'bandwidth': bandwidth.item(),
        'flatness': flatness.item(),
        'richness': richness.item()
    }



def save_feature_csv(flat_df, save_path="features.csv"):
    metrics = ['Coherence', 'Musicality', 'Memorability', 'Clarity', 'Naturalness']
    song_avg = flat_df.groupby('song_path')[metrics].mean().reset_index()
    feature_rows = []

    # --- Start of Fix ---

    # 1. Check if the file already exists to decide on writing the header.
    # This decision is made only ONCE.
    # write_header = not os.path.exists(save_path)
    
    processed_paths = set()
    # 2. If the file exists, read the already processed paths to avoid re-computing.
    if not write_header:
        try:
            existing_df = pd.read_csv(save_path)
            processed_paths = set(existing_df['song_path'].tolist())
        except pd.errors.EmptyDataError:
            # If the file exists but is empty, we still need a header.
            write_header = True
        except Exception as e:
            print(f"Could not read existing CSV, proceeding with caution. Error: {e}")

    # --- End of Fix ---

    for i, r in tqdm(song_avg.iterrows(), total=len(song_avg)):
        song_path = r['song_path']
        if song_path in processed_paths:
            continue

        try:
            y = load_audio(song_path)
        except Exception as e:
            print(f"Error loading {song_path}: {e}")
            continue

        try:
            features = compute_features(y)
            features['song_path'] = song_path
            features['avg_score'] = r[metrics].mean()
            feature_rows.append(features)
        except Exception as e:
            print(f"Error computing features for {song_path}: {e}")
            continue

        if len(feature_rows) >= 20:
            df_to_save = pd.DataFrame(feature_rows)
            # 3. Use the 'write_header' flag. It's either True for the first batch or always False.
            df_to_save.to_csv(save_path, mode='a', index=False, header=write_header)
            feature_rows.clear()
            
            # 4. After the first potential write, ensure the header is never written again in this run.
            write_header = False

        del y, features
        torch.cuda.empty_cache()
        gc.collect()

    if feature_rows:
        df_to_save = pd.DataFrame(feature_rows)
        # Also use the flag for the final batch.
        df_to_save.to_csv(save_path, mode='a', index=False, header=write_header)


def get_feature_df(dataset):
  # Flattening the datase
  flat_df = flatten_dataset(dataset)

  # Extracting features and saving in a csv
  save_feature_csv(flat_df)

  # Loading the CSV
  df = pd.read_csv('features.csv')

  # Selecting features and target
  X = df[['centroid', 'bandwidth', 'flatness', 'richness']].values  # shape: (num_samples, 4)
  y = df['avg_score'].values  # shape: (num_samples,)
  return X, y



def compute_mel_spectrogram(y, device='cuda'):
  mel_spec = torchaudio.transforms.MelSpectrogram(
    sample_rate=16000,
    n_fft=2048,
    hop_length=512,
    n_mels=128,
  ).to(device)
  to_db = torchaudio.transforms.AmplitudeToDB().to(device)
  y.to(device)
  S = mel_spec(y)
  S_db = to_db(S)
  return S_db.squeeze(0)

# Compute and save Mel spectrograms and targets in batches as .npy files.
# Skips batches that are already saved.
def save_mel_spectrograms_batched(song_paths, targets, batch_size=20, save_dir='mel_batches', device='cuda', target_length=1292):
    os.makedirs(save_dir, exist_ok=True)

    num_samples = len(song_paths)
    num_batches = (num_samples + batch_size - 1) // batch_size

    for batch_idx in range(num_batches):
        mel_batch_path = f"{save_dir}/mel_batch_{batch_idx}.npy"
        target_batch_path = f"{save_dir}/target_batch_{batch_idx}.npy"

        if os.path.exists(mel_batch_path) and os.path.exists(target_batch_path):
            print(f"Skipping batch {batch_idx} (already saved)")
            continue

        mel_specs = []
        valid_targets = []

        start = batch_idx * batch_size
        end = min(start + batch_size, num_samples)

        # Correctly iterate using an index
        for i in range(start, end):
            # Get the song path and target directly from the lists
            song_path = song_paths[i]
            target = targets[i]
            
            try:
                y = load_audio(song_path, device=device)
                mel = compute_mel_spectrogram(y, device)


                current_length = mel.shape[1]
                if current_length > target_length:
                    # Truncate if longer
                    mel = mel[:, :target_length]
                elif current_length < target_length:
                    # Pad with zeros if shorter
                    padding_needed = target_length - current_length
                    # (pad_left, pad_right) for the last dimension
                    mel = F.pad(mel, (0, padding_needed))
                # --- End of Padding/Truncating Logic ---

                
                mel_np = mel.cpu().numpy()
                mel_specs.append(mel_np)
                valid_targets.append(target)
                if i == 0 and batch_idx == 0:
                    print(f"Shape of first Mel spectrogram: {mel_np.shape}")
            except Exception as e:
                # Use the 'song_path' variable for a clear error message
                print(f"Error processing {song_path}: {e}")
                continue
        
        if mel_specs:
            mel_specs_arr = np.stack(mel_specs)
            valid_targets_arr = np.array(valid_targets)
            np.save(mel_batch_path, mel_specs_arr)
            np.save(target_batch_path, valid_targets_arr)
            print(f"Saved batch {batch_idx} with {mel_specs_arr.shape[0]} samples.")

        mel_specs.clear()
        valid_targets.clear()
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    print("All batches processed and saved successfully!")



def load_all_mel_batches(save_dir='mel_batches'):

    # Loads all mel spectrogram and target batches from the given directory,
    # concatenates them, and returns as numpy arrays and a DataFrame.

    mel_list = []
    target_list = []
    batch_idx = 0

    while True:
        mel_path = os.path.join(save_dir, f"mel_batch_{batch_idx}.npy")
        target_path = os.path.join(save_dir, f"target_batch_{batch_idx}.npy")
        if not (os.path.exists(mel_path) and os.path.exists(target_path)):
            break
        mel = np.load(mel_path)
        target = np.load(target_path)
        mel_list.append(mel)
        target_list.append(target)
        batch_idx += 1

    if not mel_list:
        raise ValueError("No mel spectrogram batches found in the directory.")

    mel_specs = np.concatenate(mel_list, axis=0)
    targets = np.concatenate(target_list, axis=0)
    df = pd.DataFrame({'mel_spec': list(mel_specs), 'target': targets})

    print(f"Loaded {mel_specs.shape[0]} samples. Mel shape: {mel_specs.shape[1:]}")
    return mel_specs, targets, df



# Function to transform the waveform into useful embeddings (data in form of integers)
def get_embedding(waveform, processor, model, device='cpu'):
    waveform = waveform.to(device) # Push the waveform to GPU where model is

    # Pass these waveforms to the processor which will give us these as inputs in required format that we will give to the model
    inputs = processor(waveform.cpu().squeeze().numpy(),
                       sampling_rate=16000,
                       return_tensors="pt",
                       padding=True)

    # Pushing these inputs to the GPU where the model is
    inputs = {k: v.to(device) for k, v in inputs.items()}

    # Passing the inputs to the model to get the required embeddings
    with torch.no_grad():
        outputs = model(**inputs)

    embedding = outputs.last_hidden_state.mean(dim=1).squeeze().cpu().numpy()

    # deleting waveform and other shii to free GPU memory
    del waveform, inputs, outputs
    torch.cuda.empty_cache()

    return embedding


# Function to get the length of song
# Since we poor as heck and using free version of colab
# After a lot of testing i found that a song longer than 5 minutes consumes too much GPU space that is not available in the free version
# So we need to get length of each song and skip those which are longer than 5 mins

def get_mp3_duration(path):
    try:
        audio = MP3(path)
        return audio.info.length
    except Exception as e:
        print(f"Error reading {path}: {e}")
        return 0

# Because of limited GPU memory, we divide songs into batches
# After testing, I found that max 2 songs are processed before GPU memory is full
# So we have batches of two songs
# Also we set max length of song as 300 secs (5 mins)
# Since we can use GPU for a limited time and it takes a lot of time to process, we process only 100 songs for now

MAX_SECONDS = 300
BATCH_SIZE = 2
NUM_SONGS = 500


SAVE_DIR = "/content/drive/MyDrive/song_embeddings"


def process_batches(dataset, processor, model, batch_size=BATCH_SIZE, num_songs= NUM_SONGS, save_dir= SAVE_DIR):
  for i in tqdm(range(0, num_songs, batch_size), desc="Processing batches"):
    os.makedirs(save_dir, exist_ok=True)
    batch_X_path = os.path.join(save_dir, f"batch_X_{i}.npy")
    batch_y_path = os.path.join(save_dir, f"batch_y_{i}.npy")

    # Skipping if batch already exists
    if os.path.exists(batch_X_path) and os.path.exists(batch_y_path):
        print(f"Skipping batch {i//batch_size + 1} (already saved)")
        continue

    batch_X, batch_y = [], []

    # Making batches according to current song and batch size
    batch = dataset.select(range(i, min(i + batch_size, num_songs)))

    # Clearing previous batch as its already saved
    batch_X.clear()

    for row in batch:
      path = row['audio']['path'] # Getting path of song
      length = get_mp3_duration(path)

      if length > MAX_SECONDS: # Skipping longer songs
        print(f"Skipping {path}, too long: {length:.1f}s")
        continue

      waveform = load_audio(path)
      embedding = get_embedding(waveform, processor= processor, model= model)
      embedding = embedding.astype(np.float32)  # Lower memory consumed as compared to float64, so safer for CPU

      # In dataset we have got 4 to 5 values of Musicality for each song
      # (prolly diff reviews taken from diff ppl)
      # So we take average of these and take that as the y value (result)

      avg_mus = np.mean([a['Musicality'] for a in row['annotation']])

      batch_X.append(embedding)
      batch_y.append(avg_mus)

      # Freeing GPU memory
      del waveform, embedding
      torch.cuda.empty_cache()


    # Saving the embeddings as files so we can load them later
    if batch_X:
        np.save(batch_X_path, np.array(batch_X))
        np.save(batch_y_path, np.array(batch_y))
        print(f"Saved batch {i//BATCH_SIZE + 1}")

    # Force garbage collection to prevent memory leaks
    gc.collect()
    torch.cuda.empty_cache()

  print("\nAll batches processed and saved successfully!")
