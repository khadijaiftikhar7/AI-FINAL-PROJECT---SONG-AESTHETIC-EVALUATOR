import json
import os
import matplotlib.pyplot as plt

def ensure_dirs():
    os.makedirs("plots", exist_ok=True)

def load_results():
    with open("results/baseline_metrics.json") as f:
        baseline = json.load(f)
    with open("results/proposed_metrics.json") as f:
        proposed = json.load(f)
    return baseline, proposed

def plot_bars():
    baseline, proposed = load_results()
    models = ["Baseline", "Proposed"]

    # MSE
    plt.figure()
    plt.bar(models, [baseline["mse"], proposed["mse"]])
    plt.title("MSE Comparison")
    plt.savefig("plots/mse_comparison.pdf")

    # R²
    plt.figure()
    plt.bar(models, [baseline["r2"], proposed["r2"]])
    plt.title("R² Comparison")
    plt.savefig("plots/r2_comparison.pdf")

def main():
    ensure_dirs()
    plot_bars()
    print("Saved plots in 'plots/' folder")

if __name__ == "__main__":
    main()
