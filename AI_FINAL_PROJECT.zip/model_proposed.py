from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import RandomizedSearchCV

def build_base_rf():
    return RandomForestRegressor(
        n_estimators=200,
        random_state=67,
        n_jobs=-1
    )

def get_param_distributions():
    return {
        "n_estimators": [100, 200, 400],
        "max_depth": [None, 10, 20, 40],
        "min_samples_split": [2, 5, 10],
        "min_samples_leaf": [1, 2, 4],
        "max_features": ["sqrt", "log2"],
    }

def tune_hyperparameters(model, X_train, y_train):
    search = RandomizedSearchCV(
        estimator=model,
        param_distributions=get_param_distributions(),
        n_iter=20,
        cv=5,
        scoring="neg_mean_squared_error",
        n_jobs=-1,
        verbose=1,
        random_state=67
    )
    search.fit(X_train, y_train)
    return search
