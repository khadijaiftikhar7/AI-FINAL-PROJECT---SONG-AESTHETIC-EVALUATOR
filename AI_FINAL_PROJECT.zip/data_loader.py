from datasets import load_dataset
import pandas as pd

def load_data():
    """
    Load the SongEval dataset from Hugging Face.
    Returns a Hugging Face dataset object.
    """
    dataset = load_dataset("ASLP-lab/SongEval", split="train")
    # Do NOT cast to Audio — avoids torchcodec errors
    return dataset

def flatten_dataset(dataset):
    """
    Flatten the dataset to have one row per annotation.
    Each row contains annotation info + song path.
    """
    rows = []
    for song in dataset:
        song_path = song['audio']['path']  # path to mp3/wav file
        for ann in song['annotation']:
            ann['song_path'] = song_path
            rows.append(ann)
    flat_df = pd.DataFrame(rows)
    return flat_df

import pandas as pd
from sklearn.model_selection import train_test_split

def train_test_split_data(csv_path, target_col, test_size=0.2, random_state=67):
    df = pd.read_csv(csv_path)
    
    # Drop rows with missing features or target
    df = df.dropna(subset=['centroid','bandwidth','flatness','richness', target_col])
    
    X = df[['centroid', 'bandwidth', 'flatness', 'richness']].values
    y = df[target_col].values
    
    return train_test_split(X, y, test_size=test_size, random_state=random_state)

