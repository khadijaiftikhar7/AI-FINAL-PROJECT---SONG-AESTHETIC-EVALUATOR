from sklearn.ensemble import RandomForestRegressor

# Trains model based on data provided
# Model is Random Forest (rf)
# Args:
# X_train (inputs of training data)
# y_train (outputs of training data)

def train_baseline_B(X_train, y_train):
  model = RandomForestRegressor(n_estimators=100, random_state=67)
  model.fit(X_train, y_train)
  return model

# Uses model trained and makes predictions of test dataset inputs
def predict_baseline_B(model, X_test):
  return model.predict(X_test)
