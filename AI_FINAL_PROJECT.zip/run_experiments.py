import json
import os
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error

from data_loader import train_test_split_data
from model_proposed import build_base_rf, tune_hyperparameters

# Update this path to your uploaded CSV in Colab
FEATURES_CSV_PATH = "/content/features.csv"
TARGET_COL = "avg_score"

def ensure_dirs():
    os.makedirs("results", exist_ok=True)
    os.makedirs("plots", exist_ok=True)

def run_baseline():
    """Train and evaluate baseline Random Forest model."""
    X_train, X_test, y_train, y_test = train_test_split_data(FEATURES_CSV_PATH, TARGET_COL)

    baseline_model = RandomForestRegressor(
        n_estimators=100,
        max_features="sqrt",  # fixed from 'auto'
        bootstrap=True,
        random_state=67,
        n_jobs=-1
    )

    baseline_model.fit(X_train, y_train)
    y_pred = baseline_model.predict(X_test)

    # Save predictions
    pd.DataFrame({"y_true": y_test, "y_pred": y_pred}).to_csv(
        "results/baseline_predictions.csv", index=False
    )

    metrics = {
        "mse": mean_squared_error(y_test, y_pred),
        "r2": r2_score(y_test, y_pred),
        "mae": mean_absolute_error(y_test, y_pred)
    }

    with open("results/baseline_metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    print("Baseline Metrics:", metrics)
    return X_train, X_test, y_train, y_test

def run_proposed():
    """Train and evaluate proposed tuned Random Forest model."""
    X_train, X_test, y_train, y_test = train_test_split_data(FEATURES_CSV_PATH, TARGET_COL)

    base_model = build_base_rf()
    search = tune_hyperparameters(base_model, X_train, y_train)
    best_model = search.best_estimator_

    y_pred = best_model.predict(X_test)

    # Save predictions
    pd.DataFrame({"y_true": y_test, "y_pred": y_pred}).to_csv(
        "results/proposed_predictions.csv", index=False
    )

    metrics = {
        "mse": mean_squared_error(y_test, y_pred),
        "r2": r2_score(y_test, y_pred),
        "mae": mean_absolute_error(y_test, y_pred),
        "best_params": search.best_params_
    }

    # Save cross-validation results
    pd.DataFrame(search.cv_results_).to_csv("results/proposed_cv_results.csv", index=False)

    with open("results/proposed_metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    print("Proposed Model Metrics:", metrics)

def main():
    ensure_dirs()
    print("Running Baseline Model...")
    run_baseline()
    print("\nRunning Proposed Model...")
    run_proposed()

if __name__ == "__main__":
    main()
